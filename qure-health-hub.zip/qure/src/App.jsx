import React from 'react';
import './index.css';
import Index from './pages/Index';

const App = () => <Index />;

export default App;
